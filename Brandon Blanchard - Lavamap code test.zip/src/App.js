import './App.css';
import { FurnitureCustomization } from './components';

function App() {
  return (
    <div className="App">
      <FurnitureCustomization/>
    </div>
  );
}

export default App;
