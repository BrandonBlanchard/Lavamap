# Lavamap Code Test
Thanks again for the interest, this was a really enjoyable project.

Brandon

## Setup
- `cd ./furniture-prototype`
- `npm i`
- `npm run start`